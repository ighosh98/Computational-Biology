INDRANEEL GHOSH 2016B1A70938P
Code is written in Python3.6
Explanation:
As of now the code is written taking the file titled 'f2016b1a70938p.fasta'. It can essentially be modified into any file type by changing the code

Note: Libraries used: Biopython(This must be installed in the system for the code to execute efficiently)
If your system does not have Biopython steps:
1. Go to terminal.
2. To install biopython:'pip install biopython'
3. Go to the directory where the file has been extracted/downloaded.
4. To run the script: 'python3.6  f2016b1a70938p.py'
